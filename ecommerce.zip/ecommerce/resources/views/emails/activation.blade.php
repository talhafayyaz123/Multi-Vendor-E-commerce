Welcome, {{ $name }}
Please activate your account : {{ url('user/activation', $link)}}