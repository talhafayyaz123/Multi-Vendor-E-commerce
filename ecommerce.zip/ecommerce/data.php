<?php 

/*Inserting data*/
$data = ' red | Green | blue ';
$data = explode('|', $dats);
$data = serialize($data);

/*Ending inserting data*/



?>