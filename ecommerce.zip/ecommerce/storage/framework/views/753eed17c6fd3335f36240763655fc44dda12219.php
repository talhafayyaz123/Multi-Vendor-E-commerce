
<div class="header-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-lg-3">
                <div class="log-link">
                    <?php if($user): ?>
                        <h4>Welcome <?php echo e($user->name); ?></h4>
                    <?php else: ?>
                        <p>Welcome visitor you can</p>
                        <h5><a href="/login">Login</a> or <a href="/signup">Create an account</a></h5><br>
                <a href="<?php echo e(asset('/vendor-signup')); ?>" class="btn btn-sm btn-warning" role="button">BECOME A VENDOR</a>
                <?php endif; ?>
                </div>

            </div>
            <div class="col-sm-4 col-lg-6">
                <div class="logo text-center">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('img/header/logo.png')); ?>" alt="" />
                        <h6>Home of African Fashion</h6>
                    </a>
                </div>
            </div>
            <div class="col-sm-4 col-lg-3">
                <div class="cart-info float-right">
                    <a href="<?php echo e(route('cart.index')); ?>">
                        <h5>My cart <span><?php echo e(Cart::count()); ?></span> items - <span>#<?php echo e(Cart::subTotal()); ?></span></h5>
                        <i class="fa fa-shopping-cart"></i>
                    </a>
                </div>
                <div class="search float-right">
                    <input type="text" value="" placeholder="Search Here...." />
                    <button class="submit"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>

