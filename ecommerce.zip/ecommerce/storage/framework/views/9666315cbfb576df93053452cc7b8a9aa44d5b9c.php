<?php $__env->startSection('content'); ?>
    <?php if($edit==0): ?>
        $name = '';
        $status = '',
        <?php else: ?>
        $name = $category_edit->name;
        $status = $edit_category->publication_satus;
    <?php endif; ?>

    <div>
        <ul class="breadcrumb">
            <li>
                <a href="#">Home</a> <span class="divider">/</span>
            </li>
            <li>
                <a href="#">Category</a>
            </li>
        </ul>
    </div>


    <div class="row-fluid sortable">
        <div class="box span5">
            <div class="box-header well" data-original-title>
                <h2><i class="icon-edit"></i> Add New Category</h2>
                <div class="box-icon">
                    <a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
                    <a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
                    <a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
                </div>
            </div>
    <div class="box-content">
        <?php
        $msg = Session::get('msg');
        if($msg) {
        ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($msg); ?></strong>
        </div>
            <?php } ?>

            <?php echo e(Form::open(array('route'=>'categories.store','class'=>'form-horizontal'))); ?>

            <fieldset>
                <legend>Add Category</legend>
                <div class="control-group">
                    <label class="control-label" for="typeahead">Name </label>
                    <div class="controls">
                        <?php echo e(Form::text('name','', array('type'=>'text',
                        'class'=>'span9 typeahead','id'=>'typeahead','data-provide'=>'typeahead','data-item'=>'4',
                        'data-source'=>'','placeholder'=>'Category Name', 'required'))); ?>

                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="selectError3"> Publication Status</label>
                    <div class="controls">
                        <?php echo e(Form::select('publication_status', ['Select', 'Publish', 'Unpublish'], null, ['id' => 'selectError3'])); ?>

                    </div>
                </div>
                <div class="form-actions">
                    <?php echo e(Form::button('Save category', array('class' => 'btn btn-primary','type'=>'submit'))); ?>

                    <?php echo e(Form::button('Cancel', array('class' => 'btn','type'=>'reset'))); ?>

                </div>
            </fieldset>
       <?php echo e(Form::close()); ?>


    </div>



    </div><!--/row-->
    <div class="box span7">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-user"></i> Categories</h2>
            <div class="box-icon">
                <a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
                <a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
                <a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
            </div>
        </div>
        <div class="box-content">
            <?php
            $msg = Session::get('message');
            if($msg) {
            ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($msg); ?></strong>
            </div>
            <?php } ?>
            <table class="table table-striped table-bordered bootstrap-datatable datatable">
                <thead>
                <tr>
                    <th>SL</th>
                    <th>Category Name</th>
                    <th>Publication Status</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php if('category'): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td class="center"><?php echo e($category->name); ?></td>
                    <td class="center">
                        <?php
                        if($category->publication_status == 1)
                        {
                            echo '<span class="label label-success">Published</span>';
                        } else {
                            echo '<span class="label label-important">Unpublished</span>';
                        }
                        ?>

                    </td>
                    <td class="center">
                        <?php if($category->publication_status == 1): ?>
                            <a class="btn btn-sm btn-danger" href="#">
                                <i class="icon-arrow-down icon-white"></i>
                            </a>

                                 <?php else: ?>

                                <a class="btn btn-sm btn-success" href="#">
                                    <i class="icon-arrow-up icon-white"></i>
                                </a>
                                <?php endif; ?>
                                <a class="btn btn-sm btn-info" href="<?php echo e(Route('categories.edit',$category->id)); ?>"
                                      style="float:left">

                                <i class="icon-edit icon-white"></i>
                                </a>
                            <?php echo e(Form::open(array('route'=> ['categories.destroy', $category->id],'method'=>'delete','style'=>'float:left'))); ?>



                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="icon-trash icon-white"></i>
                        </button>
                            <?php echo e(Form::hidden('id',$category->id)); ?>

                        <?php echo e(Form::close()); ?>

                    </td>
                </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                        <td class="center">NO DATA</td>
                <?php endif; ?>

                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div><!--/span-->


    </div><!--/span-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout_backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>