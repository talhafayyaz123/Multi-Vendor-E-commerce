<?php $__env->startSection('content'); ?>
    <?php
    if($edit==0) {
        $name = '';
        $price = '';
        $qty = '';
        $category = '';
        $brand = '';
        $action = array('route'=>'products.store','class'=>'form-horizontal','name'=>'edit','files'=>true);
    } elseif($edit ==1) {
        $id = $product_edit->id;
        $name = $product_edit->name;
        $price = $product_edit->price;
        $qty = $product_edit->qty;
        $category = $product_edit->category_id;
        $brand = $product_edit->brand_id;
        $action = array('route'=>['products.update', $id],'method'=>'PUT','class'=>'form-horizontal','name'=>'edit', 'files' => true);
    }
    ?>

    <div id="content-header">
        <div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">products</a> </div>
        <h1>Products</h1>
    </div>
    <div class="container-fluid">
        <hr>
        <div class="row-fluid">
            <div class="span4">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"> <i class="icon-list"></i> </span>
                        <h5>Add New Product</h5>
                    </div>
                    <div class="widget-content">
                        <?php
                        $msg = Session::get('msg');
                        if($msg) {
                        ?>
                        <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($msg); ?></strong>
                        </div>
                        <?php } ?>

                        <?php echo e(Form::open($action)); ?>

                        <div class="form-group">
                            <div class="col-xs-9">
                                <label>Product name</label>
                                <?php echo e(Form::text('name',$name, array('type'=>'text', 'class'=>'form-control','placeholder'=>'Product Name', 'required'))); ?>

                            </div>
                        </div>
                            <div class="form-group">
                                <div class="col-xs-9">
                                    <label>Product amount</label>
                                    <?php echo e(Form::text('price',$price, array('type'=>'number',
                               'class'=>'form-control','placeholder'=>'Product amount', 'required'))); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-9">
                                    <label>Quantity</label>
                                    <?php echo e(Form::text('qty',$qty, array('type'=>'number',
                               'class'=>'form-control','placeholder'=>'Product Quantity', 'required'))); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-9">
                                <label for="sel1">Category</label>
                                <select name="category_id">
                                        <option value="1">Select</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-9">
                                    <label for="sel1">Sub category</label>
                                    <select name="brand_id">
                                        <option value="1">Select</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-9">
                                    <label for="sel1">Upload image</label>
                                    <?php echo Form::file('image', null, ['class'=>'']); ?>

                                </div>
                            </div>
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" />

                            <?php if($edit==0): ?>
                        <?php echo e(Form::button('Save Product', array('class' => 'btn btn-primary','type'=>'submit'))); ?>

                            <?php elseif($edit==1): ?>
                                <?php echo e(Form::button('Update Product', array('class' => 'btn btn-primary','type'=>'submit'))); ?>

                                <?php endif; ?>
                        <?php echo e(Form::button('Cancel', array('class' => 'btn btn-default','type'=>'reset'))); ?>



                        <?php echo e(Form::close()); ?>



                    </div>
                </div>
            </div>

            <div class="span8">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
                        <h5>Products</h5>
                    </div>
                    <?php
                    $msg = Session::get('message');
                    if($msg) {
                    ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($msg); ?></strong>
                    </div>
                    <?php } ?>
                    <div class="widget-content">
                        <div class="widget-content nopadding">
                            <table class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Product name</th>
                                    <th>Product Amount</th>
                                    <th>Product Qty</th>
                                    <th>Category</th>
                                    <th>Sub category</th>
                                    <th>User</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if('Products'): ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="taskDesc"><?php echo e($product->name); ?></td>
                                            <td class="taskDesc">#<?php echo e($product->price); ?></td>
                                            <td class="taskDesc"><?php echo e($product->qty); ?></td>
                                            <td class="taskDesc"><?php echo e($product->category->name); ?></td>
                                            <td class="taskDesc"><?php echo e($product->brand->name); ?></td>
                                            <td class="taskDesc"><?php echo e($product->user->name); ?></td>
                                            <td class="taskDesc"><img src="<?php echo e(asset('img/uploads/'.$product->image)); ?>" height="50px" alt=""></td>
                                            <td class="taskOptions">
                                                <?php echo Form::open(array('url'=>['products', $product->id],'method'=>'PUT','style'=>'float:left')); ?>

                                                <?php echo e(Form::hidden('id',$product->id)); ?>

                                                <?php echo Form::close(); ?>


                                                <?php if($edit==0): ?>
                                                <a href="<?php echo e(Route('products.edit',$product->id)); ?>"  style="float:left" class="btn btn-sm btn-info">

                                                    <i class="icon-edit"></i>
                                                </a>
                                                <?php echo e(Form::open(array('route'=> ['products.destroy', $product->id],'method'=>'delete','style'=>'float:left'))); ?>



                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="icon-remove"></i>
                                                </button>
                                                <?php elseif($edit==1): ?>
                                                    <?php endif; ?>
                                                <?php echo e(Form::hidden('id',$product->id)); ?>

                                                <?php echo e(Form::close()); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                                        <td class="taskDesc">NO DATA</td>

                                    <?php endif; ?>
                                <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout_backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>