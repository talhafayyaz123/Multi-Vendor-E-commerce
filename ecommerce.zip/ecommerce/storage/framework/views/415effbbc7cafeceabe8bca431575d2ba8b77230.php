<?php $__env->startSection('content'); ?>
    <div class="page-title fix"><!--Start Title-->
        <div class="overlay section">
            <h2>Shop</h2>
        </div>
    </div><!--End Title-->


    </div>
    </div>
    </div>

    <div class="login-page page fix"><!--start login Area-->
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-sm-6 col-md-5">
                    <div class="login">
                        <form id="signup-form" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <h2>Create A new Account</h2>
                            <p>Create your own account</p>
                            <label>Name<span class="<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">*</span></label>
                            <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                            <?php endif; ?>

                            <label>E-mail Address<span class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">*</span></label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>"  required/>
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <label>Password<span class="<?php echo e($errors->has('password') ? 'has-error' : ''); ?>"></span></label>
                            <input type="password" name="password" required/>
                            <?php if($errors->has('password')): ?>
                                <span class="help-block text-danger">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <label>Confirm Password<span>*</span></label>
                            <input id="password-confirm" type="password" name="password_confirmation" required/>
                            <input type="submit" value="Sign up" />  Already have an Account? <a href="<?php echo e(url('/signin')); ?>">Sign In</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div><!--End login Area-->
    </div><!--Start Shop Area-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>