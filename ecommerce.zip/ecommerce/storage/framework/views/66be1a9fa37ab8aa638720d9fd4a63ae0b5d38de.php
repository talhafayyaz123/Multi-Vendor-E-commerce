
<div class="row-fluid">
    <div id="footer" class="span12"> 2017 &copy; Intercore Solutions <a href="http://intercoresolutions.com.ng">James</a> </div>
</div>

<!--end-Footer-part-->

<?php echo e(Html::script('js/jquery.min.js')); ?>

<?php echo e(Html::script('js/bootstrap.min.js')); ?>

<?php echo e(Html::script('js/matrix.form_validation.js')); ?>

<?php echo e(Html::script('js/jquery.peity.min.js')); ?>

<?php echo e(Html::script('js/matrix.interface.js')); ?>

<?php echo e(Html::script('js/excanvas.min.js')); ?>

<?php echo e(Html::script('js/jquery.ui.custom.js')); ?>

<?php echo e(Html::script('js/jquery.validate.js')); ?>

<?php echo e(Html::script('js/jquery.dataTables.min.js')); ?>

<?php echo e(Html::script('js/jquery.wizard.js')); ?>

<?php echo e(Html::script('js/jquery.uniform.js')); ?>

<?php echo e(Html::script('js/jquery.toggle.buttons.js')); ?>

<?php echo e(Html::script('js/jquery.flot.min.js')); ?>

<?php echo e(Html::script('js/jquery.flot.resize.min.js')); ?>

<?php echo e(Html::script('js/jquery.gritter.min.js')); ?>

<?php echo e(Html::script('js/matrix.js')); ?>

<?php echo e(Html::script('js/matrix.dashboard.js')); ?>


<?php echo e(Html::script('js/select2.min.js')); ?>

<?php echo e(Html::script('js/matrix.popover.js')); ?>

<?php echo e(Html::script('js/bootstrap-colorpicker.js')); ?>

<?php echo e(Html::script('js/bootstrap-datepicker.js')); ?>

<?php echo e(Html::script('js/fullcalendar.min.js')); ?>

<?php echo e(Html::script('js/matrix.chat.js')); ?>

<?php echo e(Html::script('js/matrix.tables.js')); ?>



<script type="text/javascript">
    // This function is called from the pop-up menus to transfer to
    // a different page. Ignore if the value returned is a null string:
    function goPage (newURL) {

        // if url is empty, skip the menu dividers and reset the menu selection to default
        if (newURL != "") {

            // if url is "-", it is this page -- reset the menu:
            if (newURL == "-" ) {
                resetMenu();
            }
            // else, send page to designated URL
            else {
                document.location.href = newURL;
            }
        }
    }

    // resets the menu selection upon entry to this page:
    function resetMenu() {
        document.gomenu.selector.selectedIndex = 2;
    }
</script>
</body>
</html>
