<?php $__env->startSection('content'); ?>

        <div class="container-fluid"><hr>
            <div class="row-fluid">
                <div class="span12">
                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"> <i class="icon-briefcase"></i> </span>
                            <h5 >Orders</h5>
                        </div>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="widget-content">
                            <div class="row-fluid">

                                <div class="span6">
                                    <table class="">
                                        <tbody>
                                        <tr>
                                            <td><h4>Name: <?php echo e($order->user->name); ?></h4></td>
                                        </tr>
                                        <tr>
                                            <td class="width30">Payment ID:</td>
                                            <td class="width70"><strong><?php echo e($order->payment_id); ?></strong></td>
                                        </tr>
                                        <tr>
                                            <td>Address</td>
                                        </tr>
                                        <tr>
                                            <td>State</td>
                                        </tr>
                                        <tr>
                                            <td>Mobile Phone:</td>
                                        </tr>
                                        <tr>
                                            <td >email</td>
                                        </tr>
                                        </tbody>
                                    </table>

                                </div>

                                <div class="span6">
                                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <form action="<?php echo e(route('toggle.deliver',$order->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                    <table class="table table-bordered table-invoice">
                                        <div class="control-group pull-right">
                                            <label class="control-label">Delivered</label>
                                            <div class="controls">
                                                <input type="checkbox" value="1" name="delivered" <?php echo e($order->deliver==1?"checked":""); ?>/>
                                                <input type="submit" value="submit" />
                                            </div>
                                        </div>

                                        <tbody>
                                        <tr>
                                        <tr>
                                            <td class="width30">Item:</td>
                                            <td class="width70"><strong><?php echo e($item->name); ?></strong></td>
                                        </tr>
                                        <tr>
                                            <td>Payment Date:</td>
                                            <td><strong><?php echo e($item->created_at); ?></strong></td>
                                        </tr>
                                        <tr>
                                            <td>Quantity</td>
                                            <td><strong><?php echo e($item->pivot->qty); ?></strong></td>
                                        </tr>
                                        <td class="width30">Amount</td>
                                        <td class="width70">#<?php echo e($item->pivot->total); ?></td>
                                        </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </table>
                                        </form>
                                </div>

                            </div>

                            <div class="row-fluid">
                                <div class="span12">

                                    <div class="pull-right">
                                        <h4><span>Total Amount:</span> #<?php echo e($order->total); ?></h4>
                                        <br>
                                        <a class="btn btn-primary btn-large pull-right" href="">Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout_backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>