Welcome, <?php echo e($name); ?>

Please activate your account : <?php echo e(url('user/activation', $link)); ?>