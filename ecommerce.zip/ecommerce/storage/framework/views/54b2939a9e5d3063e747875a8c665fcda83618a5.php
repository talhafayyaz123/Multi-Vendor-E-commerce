<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('backend.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<!-- topbar starts -->
<?php echo $__env->make('backend.includes.top-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- topbar ends -->
<div class="container-fluid">
    <div class="row-fluid">

        <!-- left menu starts -->
       <?php echo $__env->make('backend.includes.side-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block span10">
                <h4 class="alert-heading">Warning!</h4>
                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
            </div>
        </noscript>
        <div id="content" class="span10">
            <!-- content starts -->
        <?php echo $__env->yieldContent('content'); ?>
        </div><!--/#content.span10-->
    </div><!--/fluid-row-->

    <hr>

    <?php echo $__env->make('backend.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
