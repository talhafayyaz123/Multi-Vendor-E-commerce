<?php
function current_page($uri= "/admin")
{
    return request()->path() == $uri;
}
?>


<?php echo $__env->make('backend.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<!--Header-part-->
<div id="header">
    <h1><a href="/admin">Pako Admin</a></h1>
</div>
<!--close-Header-part-->


<!--top-Header-menu-->
<?php echo $__env->make('backend.includes.top-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--close-top-serch-->

<!--sidebar-menu-->
<?php echo $__env->make('backend.includes.side-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
<?php echo $__env->yieldContent('content'); ?>

</div>
<!--end-main-container-part-->

<!--Footer-part-->
<?php echo $__env->make('backend.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>