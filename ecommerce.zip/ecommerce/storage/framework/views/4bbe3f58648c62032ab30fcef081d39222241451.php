<?php $__env->startSection('content'); ?>

    <div class="page-title fix"><!--Start Title-->
        <div class="overlay section">
            <h2>Cart</h2>
        </div>
    </div><!--End Title-->


    </div>
    </div>
    </div>



    <section class="cart-page page fix"><!--Start Cart Area-->
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="table-responsive">
                        <table class="table cart-table">
                            <thead class="table-title">
                            <tr>
                                <th class="produ">PRODUCT</th>
                                <th class="namedes">PRODUCT NAME &amp; DESCRIPTION</th>
                                <th class="unit">UNIT PRICE</th>
                                <th class="quantity">QUANTITY</th>
                                <th class="valu">VALUE</th>
                                <th class="acti">ACTION</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr class="table-info">
                                <td class="produ">
                                    <a href="#"><img alt="" src="img/cart-1.jpg"></a>
                                </td>
                                <td class="namedes">
                                    <h2><a href="#">PRODUCT NAME DEMO</a></h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </td>
                                <td class="unit">
                                    <h5>$120</h5>
                                </td>
                                <td class="quantity">
                                    <div class="cart-plus-minus">
                                        <input type="text" value="0" name="qtybutton" class="cart-plus-minus-box">
                                    </div>
                                </td>
                                <td class="valu">
                                    <h5>$120</h5>
                                </td>
                                <td class="acti">
                                    <a href="#"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                            <tr class="table-info">
                                <td class="produ">
                                    <a href="#"><img alt="" src="img/cart-2.jpg"></a>
                                </td>
                                <td class="namedes">
                                    <h2><a href="#">PRODUCT NAME DEMO</a></h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </td>
                                <td class="unit">
                                    <h5>$120</h5>
                                </td>
                                <td class="quantity">
                                    <div class="cart-plus-minus">
                                        <input type="text" value="0" name="qtybutton" class="cart-plus-minus-box">
                                    </div>
                                </td>
                                <td class="valu">
                                    <h5>$120</h5>
                                </td>
                                <td class="acti">
                                    <a href="#"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-sm-6 col-md-7">
                    <div class="coupon">
                        <a href="#">Continue Shopping</a>
                        <h3>DISCOUNT COUPON CODE</h3>
                        <input type="text" placeholder="DISCOUNT COUPON CODE HERE..." />
                        <a href="#">Apply Coupon</a>
                        <p><span>NOTE :</span> Shipping and Taxes are estimated and updated during checkout based on your billing and shipping information.</p>
                    </div>
                </div>
                <div class="col-sm-6 col-md-5">
                    <div class="proceed fix">
                        <a href="#">CLEAR SHOPPING CART</a>
                        <a href="#">UPDATE SHOPPING CART</a>
                        <div class="total">
                            <h5>Sub Total <span>$420</span></h5>
                            <h6>Grand Total <span>$420</span></h6>
                        </div>
                        <a id="procedto" href="checkout.html">PROCEED TO CHECK OUT</a>
                    </div>
                </div>
            </div>
        </div>
    </section><!--End Cart Area-->

    <div class="support-area section fix"><!--Start Support Area-->
        <div class="container">
            <div class="row">
                <div class="support col-sm-3">
                    <i class="fa fa-thumbs-up"></i>
                    <h3>High quality</h3>
                    <p>Lorem ipsum dolor sit amet, conseetur adipiscing elit, consectetur</p>
                </div>
                <div class="support col-sm-3">
                    <i class="fa fa-bus"></i>
                    <h3>Fast Delivery</h3>
                    <p>Lorem ipsum dolor sit amet, conseetur adipiscing elit, consectetur</p>
                </div>
                <div class="support col-sm-3">
                    <i class="fa fa-phone"></i>
                    <h3>24/7 support</h3>
                    <p>Lorem ipsum dolor sit amet, conseetur adipiscing elit, consectetur</p>
                </div>
                <div class="support col-sm-3">
                    <i class="fa fa-random"></i>
                    <h3>14 - Day Returns</h3>
                    <p>Lorem ipsum dolor sit amet, conseetur adipiscing elit, consectetur</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>