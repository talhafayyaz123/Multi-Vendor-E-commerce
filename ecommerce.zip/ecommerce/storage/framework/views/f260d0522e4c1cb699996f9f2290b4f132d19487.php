<div class="span2 main-menu-span">
    <div class="well nav-collapse sidebar-nav">
        <ul class="nav nav-tabs nav-stacked main-menu">
            <li class="nav-header hidden-tablet">Main</li>
            <li><a class="ajax-link" href="/myadmin"><i class="icon-home"></i><span class="hidden-tablet"> Dashboard</span></a></li>
            <li><a class="ajax-link" href="/categories"><i class="icon-eye-open"></i><span class="hidden-tablet"> Categories</span></a></li>
            <li><a class="ajax-link" href="/brands"><i class="icon-edit"></i><span class="hidden-tablet"> Brands</span></a></li>
            <li><a class="ajax-link" href="/products-management"><i class="icon-list-alt"></i><span class="hidden-tablet"> Products</span></a></li>
            <li><a class="ajax-link" href="/orders"><i class="icon-font"></i><span class="hidden-tablet"> Orders</span></a></li>
            <li><a class="ajax-link" href="/settings"><i class="icon-picture"></i><span class="hidden-tablet"> Theme Settings</span></a></li>
        </ul>
    </div><!--/.well -->
</div><!--/span-->