<?php $__env->startSection('content'); ?>
    <div class="page-title fix"><!--Start Title-->
        <div class="overlay section">
            <h2>Shop</h2>
        </div>
    </div><!--End Title-->

    </div>
    </div>
    </div>

    <div class="shop-product-area section fix"><!--Start Shop Area-->
        <div class="container">
            <?php if(Session::has('success')): ?>
            <div class="row">
                <div class="col-sm-6 col-md-4 col md-offset-4 col-sm-offset-3">
                    <div id="charge-message" class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="shop-tool-bar col-sm-12 fix">
                    <div class="sort-by">
                        <span>Sort By</span>
                        <select name="sort-by">
                            <option selected="selected" value="mercede">price: Lower</option>
                            <option value="saab">price(low&gt;high)</option>
                            <option value="mercedes">price(high &gt; low)</option>
                            <option value="audi">rating(highest)</option>
                        </select>
                    </div>
                    <div class="show-product">
                        <span>Show</span>
                        <select name="sort-by">
                            <option selected="selected" value="mercede">16</option>
                            <option value="saab">20</option>
                            <option value="mercedes">24</option>
                        </select>
                        <span>Per Page</span>
                    </div>
                    <div class="pro-Showing">
                        <span>Showing 1 - 12 of 16 items</span>
                    </div>
                </div>
                <div class="shop-products">
                    <!-- Single Product Start -->
                   <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-4 col-md-3 fix">
                        <div class="product-item fix">
                            <div class="product-img-hover">
                                <!-- Product image -->
                                <a href="details/<?php echo e($product->id); ?>" class="pro-image fix"><img src="<?php echo e(asset('img/uploads/'.$product->image)); ?>" alt="product" /></a>
                                <!-- Product action Btn -->
                                <div class="product-action-btn">
                                    <a class="add-cart" href="<?php echo e(route('cart.show',$product->id)); ?>"><i class="fa fa-shopping-cart">Add to cart</i></a>
                                </div>
                            </div>
                            <div class="pro-name-price-ratting">
                                <!-- Product Name -->
                                <div class="pro-name">
                                    <a href="details/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a>
                                </div>
                                <!-- Product Ratting -->
                                <div class="pro-ratting">
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star-half-o"></i>
                                </div>
                                <!-- Product Price -->
                                <div class="pro-price fix">
                                    <p><span class="old">$165</span><span class="new">#<?php echo e($product->price); ?></span></p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Single Product End -->
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                       <li>NO DATA</li>
                       <?php endif; ?>
                    </div>
                    <!-- Pagination -->
                    <div class="pagination">
                        <ul>
                            <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                            <li class="active"><span>1</span></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#">6</a></li>
                            <li><a href="#">7</a></li>
                            <li><a href="#">8</a></li>
                            <li><a href="#">9</a></li>
                            <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div><!--Start Shop Area-->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>