<?php $__env->startSection('content'); ?>
    <!-- HOME SLIDER -->
    <div class="slider-wrap home-1-slider">
        <div id="mainSlider" class="nivoSlider slider-image">
            <img src="<?php echo e(asset('img/slider/banner1.jpg')); ?>" alt="main slider" title="#htmlcaption1"/>
            <img src="<?php echo e(asset('img/slider/banner2.jpg')); ?>" alt="main slider" title="#htmlcaption2"/>
        </div>
        
            
            
                
                    
                        
                    
                
            
        
        
            
            
                
                    
                        
                    
                
            
        
    </div>



    <div class="home-3-slider col-md-9 col-lg-10">
        <div id="mainSlider" class="nivoSlider slider-image">
            <img src="<?php echo e(asset('img/slider/banner1.jpg')); ?>" alt="main slider" title="#htmlcaption1"/>
            <img src="<?php echo e(asset('img/slider/banner2.jpg')); ?>" alt="main slider" title="#htmlcaption2"/>
        </div>
        
            
            
                
                    
                        
                    
                
            
        
        
            
            
                
                    
                        
                    
                
            
        
    </div>
    <!--End Slider Area-->

    </div>
    </div>
    </div>



    <!--start Featured Product Area-->
    <div class="featured-product section fix">
        <div class="container">
            <div class="row">
                <div class="section-title">
                    <h2>New Collection</h2>
                    <div class="underline"></div>
                </div>
                <div class="shop-products">
                    <!-- Single Product Start -->
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col-sm-4 col-md-3 fix" id="product<?php echo e($product->id); ?>">
                        <div class="product-item fix">
                            <div class="product-img-hover">
                                <!-- Product image -->
                                <a href="details/<?php echo e($product->id); ?>" class="pro-image fix"><img src="<?php echo e(asset('img/uploads/'.$product->image)); ?> " alt="product" height="250px" width="250px"/></a>
                                <!-- Product action Btn -->
                            </div>
                            <div class="pro-name-price-ratting">
                                <!-- Product Name -->
                                <div class="pro-name">
                                    <a href="details/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a>
                                </div>
                                <!-- Product Ratting -->
                                <div class="pro-ratting">
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star"></i>
                                    <i class="on fa fa-star-half-o"></i>
                                </div>
                                <!-- Product Price -->
                                <div class="pro-price fix">
                                    <p><span class="new">#<?php echo e($product->price); ?></span></p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="">
                                <a class="btn btn-warning" href="<?php echo e(route('cart.show',$product->id)); ?>"><i class="fa fa-shopping-cart"></i> Add to cart</a>

                                <a class="btn btn-warning" href="<?php echo e(route('cart.show',$product->id)); ?>">BUY NOW</a>
                            </div>

                        </div>

                    </div><!-- Single Product End -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
                <br>
            </div>
        </div>
    </div><!--End Featured Product Area-->
    <div class="banner-area fix"><!-- Product Offer Area Start -->
        <div class="col-sm-6 sin-banner">
            <a href="<?php echo e(url('/subcategory/3')); ?>">
                <img src="img/offer/bags.jpg" alt="" />
                <div class="wrap">
                    <h2>Bags</h2>
                    <p>perspiciatis unde omnis iste natus error sit voluptatem accm doloremque antium</p>
                </div>
            </a>
        </div>
        <div class="col-sm-4 sin-banner">
            <a href="#">
                <img src="img/offer/shoes.jpg" alt="" />
                <div class="wrap">
                    <h2>Shoes</h2>
                    <p>perspiciatis unde omnis iste natus error sit voluptatem accm doloremque antium</p>
                </div>
            </a>
        </div>
        <div class="col-sm-2 hidden-xs sin-banner text-1">
            <img src="img/offer/new_arrival.jpg" alt="" />
            <div class="banner-text">
                <h1><span>New</span></h1>
                <h2>Arrivals</h2>
                <p>perspiciatis unde omnis iste natus error sit voluptatem accm doloremque antium</p>
                <a href="#">Shop Now</a>
            </div>
        </div>
        <div class="col-sm-2 hidden-xs sin-banner clear text-2">
            <img src="img/offer/new_arrival.jpg" alt="" />
            <div class="banner-text">
                <h1>Sales <span>Up to</span></h1>
                <h2><span>30%</span>off</h2>
                <a href="#">Shop Now</a>
            </div>
        </div>
        <div class="col-sm-6 sin-banner">
            <a href="#">
                <img src="img/offer/rings.jpg" alt="" />
                <div class="wrap">
                    <h2>Rings</h2>
                    <p>perspiciatis unde omnis iste natus error sit voluptatem accm doloremque antium</p>
                </div>
            </a>
        </div>
        <div class="col-sm-4 sin-banner">
            <a href="#">
                <img src="img/offer/necklaces.jpg" alt="" />
                <div class="wrap">
                    <h2>Necklaces</h2>
                    <p>perspiciatis unde omnis iste natus error sit voluptatem accm doloremque antium</p>
                </div>
            </a>
        </div>
    </div><!-- Product Offer Area End -->


    <div class="testimonial-area fix"><!--Start Testimonial Area-->
        <div class="overlay section">
            <div class="container">
                <div class="row">
                    <div class="col-sm-offset-2 col-sm-8">
                        <div class="testimonial-slider  owl-carousel">
                            <div class="testimonial-item">
                                <div class="image fix">
                                    <img src="img/testimonial/testimonial.jpg" alt="" />
                                </div>
                                <div class="content fix">
                                    <p>Lorem ipsum dolor sit amet, consectetur adiising elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...</p>
                                    <h3>Zasika Williams</h3>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="image fix">
                                    <img src="img/testimonial/testimonial.jpg" alt="" />
                                </div>
                                <div class="content fix">
                                    <p>Lorem ipsum dolor sit amet, consectetur adiising elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...</p>
                                    <h3>Zasika Williams</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!--End Testimonial Area-->



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>