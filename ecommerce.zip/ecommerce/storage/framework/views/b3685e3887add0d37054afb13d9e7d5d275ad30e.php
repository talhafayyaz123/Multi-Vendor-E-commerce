
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pako Admin</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php echo e(Html::style('css/bootstrap.min.css')); ?>

    <?php echo e(Html::style('css/bootstrap-responsive.min.css')); ?>

    <?php echo e(Html::style('css/fullcalendar.css')); ?>

    <?php echo e(Html::style('css/matrix-style.css')); ?>

    <?php echo e(Html::style('css/matrix-media.css')); ?>

    <?php echo e(Html::style('font-awesome/css/font-awesome.css')); ?>

    <?php echo e(Html::style('css/jquery.gritter.css')); ?>

    <?php echo e(Html::style('css/colorpicker.css')); ?>

    <?php echo e(Html::style('css/datepicker.css')); ?>

    <?php echo e(Html::style('css/uniform.css')); ?>

    <?php echo e(Html::style('css/select2.css')); ?>

    <?php echo e(Html::style('css/bootstrap-wysihtml5.css')); ?>

    <?php echo e(Html::style('css/multiselect.css')); ?>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>