<?php $__env->startSection('content'); ?>

    <div class="row-fluid sortable">
        <div class="box span12">
            <div class="box-header well" data-original-title>
                <h2><i class="icon-user"></i> Users</h2>
            </div>
            <div class="box-content">
                <table class="table table-striped table-bordered bootstrap-datatable datatable">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if('users'): ?>

                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="center"><?php echo e($user->name); ?></td>
                        <td class="center"><?php echo e($user->email); ?></td>
                        <td class="center">
                            <span class="label label-success"><?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?><?php echo e($role->name); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?></span>
                        </td>
                        <td class="center">
                            <a class="btn btn-sm btn-success" href="#">
                                <i class="icon-zoom-in icon-white"></i>
                                View
                            </a>
                            <a class="btn btn-sm btn-info" href="#">
                                <i class="icon-edit icon-white"></i>
                                Edit
                            </a>
                            <a class="btn btn-sm btn-danger" href="#">
                                <i class="icon-trash icon-white"></i>
                                Delete
                            </a>
                        </td>
                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                            <li>NO USER FOUND</li>
                        <?php endif; ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div><!--/span-->

    </div><!--/span-->
    <div class="text-center"><?php echo $users->links(); ?></div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout_backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>