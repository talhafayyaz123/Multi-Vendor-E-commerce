<?php $__env->startSection('content'); ?>

    <div class="page-title fix"><!--Start Title-->
        <div class="overlay section">
            <h2>Cart</h2>
        </div>
    </div><!--End Title-->


    </div>
    </div>
    </div>




    <section class="cart-page page fix"><!--Start Cart Area-->
        <div class="container">

            <div class="row">
                <?php
                $count = Cart::count();
                ?>
                <?php if($count >= 1): ?>

                    <div class="col-sm-12">
                        <div class="table-responsive">

                            <table class="table cart-table">
                                <thead class="table-title">
                                <tr>
                                    <th class="namedes">PRODUCT NAME &amp; DESCRIPTION</th>
                                    <th class="unit">UNIT PRICE</th>
                                    <th class="quantity">QUANTITY</th>
                                    <th class="valu">VALUE</th>
                                    <th class="acti">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                                    <tr class="table-info">
                                        <td class="namedes">
                                            <h2><a href="#"><?php echo e($cartItem->name); ?></a></h2>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                        </td>
                                        <td class="unit">
                                            <h5><?php echo e($cartItem->price); ?></h5>
                                        </td>
                                        <td class="quantity">
                                            <div class="cart-plus-minus">
                                                <?php echo Form::open(['route'=>['cart.update',$cartItem->rowId],'method'=>'PUT']); ?>


                                                <input type="text" value="<?php echo e($cartItem->qty); ?>">
                                                <button type="submit" name="qty" ></button>
                                                <?php echo Form::close(); ?>


                                            </div>
                                        </td>
                                        <td class="valu">

                                            <h5><?php echo e(($cartItem->qty)*($cartItem->price)); ?></h5>

                                        </td>
                                        <td class="acti">
                                            <?php echo Form::open(['route'=>['cart.destroy',$cartItem->rowId],'method'=>'delete']); ?>

                                            <button type="submit"><i class="fa fa-trash-o"></i></button>
                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                                    <td>NO ITEMS IN THE CART</td>
                                <?php endif; ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="col-sm-6 col-md-7">

                    </div>
                    <div class="col-sm-6 col-md-5">
                        <div class="proceed fix">
                            

                            <a href="" type="submit">UPDATE SHOPPING CART</a>

                            <div class="total">
                                <h6>Total <span>#<?php echo e(Cart::subtotal()); ?></span></h6>
                            </div>

                            <a id="procedto" href="<?php echo e(route('checkout.shipping')); ?>">PROCEED TO CHECK OUT</a>

                        </div>
                    </div>
                <?php else: ?>
                    <div class="section-title">
                        <h2>NO ITEM IN THE CART</h2>
                    </div>

                <?php endif; ?>
            </div>

        </div>
    </section><!--End Cart Area-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>