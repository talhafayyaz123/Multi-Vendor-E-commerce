<?php $__env->startSection('content'); ?>
    <div class="page-title fix"><!--Start Title-->
        <div class="overlay section">
            <h2>Shop</h2>
        </div>
    </div><!--End Title-->


    </div>
    </div>
    </div>

    <div class="login-page page fix"><!--start login Area-->
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-5">
                    <div class="login">
                        <form id="login-form"method="POST" role="form" action="<?php echo e(url('/login')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success">
                                    <p>
                                        <?php echo e($message); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('warning')): ?>
                                <div class="alert alert-warning">
                                    <p>
                                        <?php echo e($message); ?>

                                    </p>
                                </div>
                            <?php endif; ?>

                            <h2>Login</h2>
                            <p>Welcome to your account</p>
                            <label for="email">E-mail Address<span class="<?php echo e($errors->has('email') ? 'has-error' : ''); ?>"></span></label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus/>
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <label>Password<span class="<?php echo e($errors->has('password') ? 'has-error' : ''); ?>"></span></label>
                            <input type="password" name="password" required/>
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <div class="remember">
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> />
                                <p>Remember me!</p>
                                <a href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password ?</a>
                            </div>
                            <input type="submit" value="login" />  Don't have an Account? <a href="<?php echo e(url('/signup')); ?>">Create an Account</a>
                        </form>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </div><!--End login Area-->
    </div><!--Start Shop Area-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>