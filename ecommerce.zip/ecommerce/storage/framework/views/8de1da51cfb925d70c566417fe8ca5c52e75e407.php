<?php $__env->startSection('content'); ?>

    <div class="row-fluid sortable">
        <div class="box span12">
            <div class="box-header well" data-original-title>
                <h2><i class="icon-user"></i> Categories</h2>
                <div class="box-icon">
                    <a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
                    <a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
                    <a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
                </div>
            </div>
            <div class="box-content">
                <table class="table table-striped table-bordered bootstrap-datatable datatable">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Category Name</th>
                        <th>Publication Status</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>David R</td>
                        <td class="center">2012/01/01</td>
                        <td class="center">
                            <span class="label label-success">Active</span>
                        </td>
                        <td class="center">
                            <a class="btn btn-sm btn-success" href="#">
                                <i class="icon-zoom-in icon-white"></i>
                                View
                            </a>
                            <a class="btn btn-sm btn-info" href="#">
                                <i class="icon-edit icon-white"></i>
                                Edit
                            </a>
                            <a class="btn btn-sm btn-danger" href="#">
                                <i class="icon-trash icon-white"></i>
                                Delete
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td>Dave Robert</td>
                        <td class="center">2012/03/01</td>
                        <td class="center">
                            <span class="label label-warning">Pending</span>
                        </td>
                        <td class="center">
                            <a class="btn btn-sm btn-success" href="#">
                                <i class="icon-zoom-in icon-white"></i>
                                View
                            </a>
                            <a class="btn btn-sm btn-info" href="#">
                                <i class="icon-edit icon-white"></i>
                                Edit
                            </a>
                            <a class="btn btn-sm btn-danger" href="#">
                                <i class="icon-trash icon-white"></i>
                                Delete
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td>Brown Blue</td>
                        <td class="center">2012/03/01</td>
                        <td class="center">
                            <span class="label label-warning">Pending</span>
                        </td>
                        <td class="center">
                            <a class="btn btn-sm btn-success" href="#">
                                <i class="icon-zoom-in icon-white"></i>
                                View
                            </a>
                            <a class="btn btn-sm btn-info" href="#">
                                <i class="icon-edit icon-white"></i>
                                Edit
                            </a>
                            <a class="btn btn-sm btn-danger" href="#">
                                <i class="icon-trash icon-white"></i>
                                Delete
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>Worth Name</td>
                        <td class="center">2012/03/01</td>
                        <td class="center">
                            <span class="label label-warning">Pending</span>
                        </td>
                        <td class="center">
                            <a class="btn btn-sm btn-success" href="#">
                                <i class="icon-zoom-in icon-white"></i>
                                View
                            </a>
                            <a class="btn btn-sm btn-info" href="#">
                                <i class="icon-edit icon-white"></i>
                                Edit
                            </a>
                            <a class="btn btn-sm btn-danger" href="#">
                                <i class="icon-trash icon-white"></i>
                                Delete
                            </a>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div><!--/span-->


    </div><!--/span-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout_backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>