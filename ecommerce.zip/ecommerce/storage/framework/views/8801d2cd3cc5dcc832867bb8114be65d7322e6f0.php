<div class="menu">
    <ul id="dc_mega-menu-orange" class="dc_mm-orange">
        <li class="<?php echo e(current_page('home') ? 'active' : ''); ?>"><a href="/">Home</a></li>
        <li class="<?php echo e(current_page('products') ? 'active' : ''); ?>"><a href="/products">Shop</a> </li>
        <li class="<?php echo e(current_page('topbrands') ? 'active' : ''); ?>"><a href="/topbrands">Top Brands</a></li>
        <li class="<?php echo e(current_page('cart') ? 'active' : ''); ?>"><a href="/cart">Cart</a></li>
        <li class="<?php echo e(current_page('contact') ? 'active' : ''); ?>"><a href="/contact">Contact</a> </li>
        <div class="clear"></div>
    </ul>
</div>